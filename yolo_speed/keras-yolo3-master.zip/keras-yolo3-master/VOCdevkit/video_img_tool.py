# -*- coding: utf-8 -*-
"""
 Created on 2021/4/11 17:53
 Filename: demo_image_2_image.py
 Author  : Taosy
 Zhihu   : https://www.zhihu.com/people/1105936347
 Github  : https://github.com/AFei19911012
 Describe: video --> image
"""

import cv2 as cv
import time
import os
import sys

if __name__ == '__main__':
    # file path
    video_name = 'QQspeed11city'
    video_path = '/face_detection/test_source/QQspeed11city.mp4'
    image_path = 'D:\demoOpenCV\VOCdevkit\VOC2007\JPEGImages\\' + video_name[:-4] + '_' + time.strftime('%Y_%m_%d', time.localtime())
    # generate a fold
    if not os.path.exists(image_path):
        os.makedirs(image_path)

    # read video
    if not os.path.isfile(video_path):
        print(video_path + ' not exist')
        sys.exit(1)
    cap = cv.VideoCapture(video_path)
    frame_count = int(cap.get(cv.CAP_PROP_FRAME_COUNT))  # 视频总帧数
    # frame --> image
    has_frame = True
    idx = 0
    while has_frame:
        has_frame, frame = cap.read()
        if has_frame and idx % 5 == 1:
            # file_name = f'{idx//5}'.zfill(6) + '.jpg'
            file_name = f'{idx//5:06d}.jpg'
            cv.imwrite(os.path.join(image_path, file_name), frame)
            print(file_name,"/",int(frame_count/5))
        idx += 1
    cap.release()
    print('Done processing.')